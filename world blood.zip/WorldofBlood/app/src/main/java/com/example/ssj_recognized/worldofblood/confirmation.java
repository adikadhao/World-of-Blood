package com.example.ssj_recognized.worldofblood;

import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class confirmation extends AppCompatActivity {

    int i;
    long count = 0;
    long size;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
    FirebaseAuth auth = FirebaseAuth.getInstance();
    ArrayList<String> accepteduid, acceptedcity;

    ArrayList<String> confirmName, confirmBlood, confirmBdate, confirmCity, confirmContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        acceptedcity = new ArrayList<>();
        accepteduid = new ArrayList<>();
        confirmName = new ArrayList<>();
        confirmBlood = new ArrayList<>();
        confirmBdate = new ArrayList<>();
        confirmCity = new ArrayList<>();
        confirmContact = new ArrayList<>();

        databaseReference.child(auth.getCurrentUser().getDisplayName())
                .child(auth.getCurrentUser().getUid()).child("accepted")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        size = dataSnapshot.getChildrenCount();

                        for(DataSnapshot snapshot : dataSnapshot.getChildren()){

                            Log.d("$$$$$$", snapshot.toString());
                            acceptedcity.add(snapshot.getValue().toString());
                            Log.d("####", snapshot.getValue().toString());
                            accepteduid.add(snapshot.getKey());
                            count ++;
                        }

                        if (size==count){
                            for (i=0; i< acceptedcity.size();i++){
                                Log.d("$$$$$$$$", acceptedcity.size()+" "+i);
                                databaseReference.child(acceptedcity.get(i)).child(accepteduid.get(i))
                                        .addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {

                                                //confirmCity.add(acceptedcity.get(i));
                                                confirmBdate.add(dataSnapshot.child("bdate").getValue().toString());
                                                confirmBlood.add(dataSnapshot.child("bloodGroup").getValue().toString());
                                                confirmName.add(dataSnapshot.child("name").getValue().toString());
                                                confirmContact.add(dataSnapshot.child("contact").getValue().toString());

                                                if(i == acceptedcity.size()){
                                                    Log.d("settttter", "SETTTTTERR CALLED");
                                                    RecyclerView recyclerView = (RecyclerView)findViewById(R.id.confirm);

                                                    RecyclerAdapter2 adapter = new RecyclerAdapter2(confirmName
                                                            , confirmCity, confirmContact, confirmBdate, confirmBlood , accepteduid, confirmation.this);
                                                    recyclerView.setAdapter(adapter);
                                                    recyclerView.setLayoutManager(new LinearLayoutManager(confirmation.this));
                                                }else {
                                                    Log.d("ELSEEEE", i+1 + " " + acceptedcity.size());
                                                }

                                            }

                                            @Override
                                            public void onCancelled(DatabaseError databaseError) {

                                            }
                                        });
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });






    }
}
