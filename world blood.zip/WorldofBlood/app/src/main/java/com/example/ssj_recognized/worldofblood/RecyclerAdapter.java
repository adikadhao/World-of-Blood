package com.example.ssj_recognized.worldofblood;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;



import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;


public class RecyclerAdapter extends  RecyclerView.Adapter<RecyclerAdapter.ViewHolder>{


    ArrayList<String> names;

    String city1;





    private Context mContext;

    public RecyclerAdapter(ArrayList<String> Names, String City, Context context){
        names = Names;
        city1 = City;

        mContext = context;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapterlayout, parent, false);
        ViewHolder holder = new ViewHolder(view);


        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        holder.name.setText(names.get(position));
        holder.city.setText(city1);



        try{
            holder.parentLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
            Log.d("SUCCESS", "SUCCESS");
        }catch (Exception e){
            Log.d("EXCEPTIOn", e.toString());
        }

    }




    @Override
    public int getItemCount() {
        return names.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        TextView name, city;
        RelativeLayout parentLayout;


        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            city = itemView.findViewById(R.id.city);



        }
    }
}
