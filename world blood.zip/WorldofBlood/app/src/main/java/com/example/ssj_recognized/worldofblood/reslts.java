package com.example.ssj_recognized.worldofblood;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class reslts extends AppCompatActivity {

    String city, blood;
    String myName;
    FirebaseAuth auth = FirebaseAuth.getInstance();

    DatabaseReference mydatabase = FirebaseDatabase.getInstance().getReference();

    String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

    ArrayList<String> names, uids;


    Button send;
    long size, cont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reslts);

        Bundle intent = getIntent().getExtras();
        city = intent.getString("city");
        blood = intent.getString("bloodGroup");

        names = new ArrayList<>();
        uids = new ArrayList<>();

        send = findViewById(R.id.send);




        mydatabase.child(city).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                size = dataSnapshot.getChildrenCount();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){

                    if (snapshot.child("bloodGroup").getValue().toString().equals(blood) && !snapshot.getKey().equals(uid)){
                        names.add(snapshot.child("name").getValue().toString());
                        uids.add(snapshot.getKey());

                    }
                    if(snapshot.getKey().equals(uid)){
                        myName = snapshot.child("name").getValue().toString();
                    }else{
                        mydatabase.child(auth.getCurrentUser().getDisplayName())
                                .child(auth.getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                myName = dataSnapshot.child("name").getValue().toString();
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });
                    }
                    Log.d("#####", snapshot.child("bloodGroup").getValue().toString() + " "+ blood);
                    Log.d("#####", snapshot.getKey().toString() + " "+ uid);
                    cont++;



                }
                if(size == cont){
                    Log.d("settttter", "SETTTTTERR CALLED");
                    Log.d("#####", names.toString());
                    RecyclerView recyclerView = (RecyclerView)findViewById(R.id.results);

                    RecyclerAdapter adapter = new RecyclerAdapter(names
                            , city, reslts.this);
                    recyclerView.setAdapter(adapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(reslts.this));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                for (int i=0; i<uids.size();i++){

                    HashMap<String, String> temp2 = new HashMap<>();
                    temp2.put("bloodGroup", blood);
                    temp2.put("name", myName);
                    temp2.put("city", auth.getCurrentUser().getDisplayName());
                    mydatabase.child(city).child(uids.get(i)).child("requests").child(uid).setValue(temp2);
                    Toast.makeText(reslts.this, "Requests Sent Successfull", Toast.LENGTH_LONG).show();

                }


            }
        });
    }
}
