package com.example.ssj_recognized.worldofblood;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


public class RecyclerAdapter1 extends  RecyclerView.Adapter<RecyclerAdapter1.ViewHolder>{


    ArrayList<String> names, city1, uids;

    DatabaseReference mydatabase = FirebaseDatabase.getInstance().getReference();
    FirebaseAuth auth = FirebaseAuth.getInstance();







    private Context mContext;

    public RecyclerAdapter1(ArrayList<String> Names, ArrayList<String> City,ArrayList<String> UIDS, Context context){
        names = Names;
        city1 = City;
        uids = UIDS;

        mContext = context;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapterlayout1, parent, false);
        ViewHolder holder = new ViewHolder(view);


        return holder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        holder.name.setText(names.get(position));
        holder.city.setText(city1.get(position));



        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mydatabase.child(city1.get(position)).child(uids.get(position)).child("accepted")
                        .child(auth.getCurrentUser().getUid()).setValue(auth.getCurrentUser().getDisplayName());
                Toast.makeText(mContext,"Accepted", Toast.LENGTH_LONG).show();
                mydatabase.child(auth.getCurrentUser().getDisplayName())
                        .child(auth.getCurrentUser().getUid())
                        .child("requests").child(uids.get(position)).removeValue();
                holder.accept.setVisibility(View.GONE);
                holder.reject.setVisibility(View.GONE);

            }
        });

        holder.reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydatabase.child(auth.getCurrentUser().getDisplayName())
                        .child(auth.getCurrentUser().getUid())
                        .child("requests").child(uids.get(position)).removeValue();
                Toast.makeText(mContext, "Rejected", Toast.LENGTH_LONG).show();
            }
        });

    }




    @Override
    public int getItemCount() {
        return names.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        TextView name, city;
        RelativeLayout parentLayout;
        Button accept, reject;


        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            city = itemView.findViewById(R.id.city);
            accept = itemView.findViewById(R.id.accept);
            reject = itemView.findViewById(R.id.reject);





        }
    }
}
