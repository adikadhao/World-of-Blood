package com.example.ssj_recognized.worldofblood;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class searchBlood extends AppCompatActivity {

    EditText city;
    RadioGroup radioGroup;
    Button logout;
    RadioButton bloodRadio;
    FirebaseAuth auth = FirebaseAuth.getInstance();

    Button search, newRequest, accepted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_blood);

        search = findViewById(R.id.search);
        city = findViewById(R.id.city);
        radioGroup = findViewById(R.id.radioGroup);
        newRequest = findViewById(R.id.newrequest);
        accepted = findViewById(R.id.accept);
        logout = findViewById(R.id.logout);


        accepted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(searchBlood.this, confirmation.class);
                startActivity(intent);
            }
        });


        newRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(searchBlood.this, fetchRequest.class);
                startActivity(intent);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                bloodRadio = (RadioButton) findViewById(selectedId);
                if(selectedId==-1){
                    Toast.makeText(searchBlood.this,"Please Select Blood Group", Toast.LENGTH_SHORT).show();
                }
                else{

                    String City = city.getText().toString();

                    Intent intent = new Intent(searchBlood.this, reslts.class);
                    intent.putExtra("city",City);
                    intent.putExtra("bloodGroup", bloodRadio.getText());
                    startActivity(intent);

                }
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.signOut();
                Intent intent = new Intent(searchBlood.this, Launcher.class);
                startActivity(intent);
                finish();
            }
        });


    }
}
