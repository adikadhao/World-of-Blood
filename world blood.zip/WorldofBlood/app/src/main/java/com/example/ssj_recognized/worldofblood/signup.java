package com.example.ssj_recognized.worldofblood;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

public class signup extends AppCompatActivity {

    EditText name, username, password, bdate, contact, city;


    DatabaseReference myDatabase;


    FirebaseAuth auth = FirebaseAuth.getInstance();

    RadioGroup radioGroup;

    Button signup;

    RadioButton bloodRadio;
    String bloodGroup, Username, Password, Bdate, Contact, Name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        name = findViewById(R.id.name);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        bdate = findViewById(R.id.bdate);
        contact = findViewById(R.id.contact);
        radioGroup = findViewById(R.id.radioGroup);
        city = findViewById(R.id.city);
        signup = findViewById(R.id.signup);

        myDatabase = FirebaseDatabase.getInstance().getReference();

        final Calendar myCalendar = Calendar.getInstance();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "dd/MM/yyyy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                bdate.setText(sdf.format(myCalendar.getTime()));
            }

        };

        bdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(signup.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                bloodRadio = (RadioButton) findViewById(selectedId);
                if(selectedId==-1){
                    Toast.makeText(signup.this,"Please Select Blood Group", Toast.LENGTH_SHORT).show();
                }
                else{
                    //Toast.makeText(signup.this,bloodRadio.getText(), Toast.LENGTH_SHORT).show();

                    bloodGroup = bloodRadio.getText().toString();
                    Name = name.getText().toString();
                    Username = username.getText().toString();
                    Bdate = bdate.getText().toString();
                    Contact = contact.getText().toString();
                    final String City = city.getText().toString();
                    Password = password.getText().toString();

                    try{
                        if(bloodGroup!=null && Name != null &&
                                Username != null && Bdate != null &&
                                Contact!=null && password != null && City != null){
                            if (Calendar.getInstance().get(Calendar.YEAR) - Integer.parseInt(Bdate.split("/")[2]) >= 18
                                    ){
                                auth.createUserWithEmailAndPassword(Username, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {

                                        if (task.isSuccessful()){
                                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                                            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                                    .setDisplayName(City)
                                                    .build();

                                            user.updateProfile(profileUpdates);

                                            HashMap<String, String> temp = new HashMap<>();
                                            temp.put("name", Name);
                                            temp.put("bdate", Bdate);
                                            temp.put("bloodGroup", bloodGroup);
                                            temp.put("contact", Contact);
                                            myDatabase.child(City).child(auth.getCurrentUser().getUid().toString()).setValue(temp).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    Toast.makeText(signup.this, "SignedUP Successfuly", Toast.LENGTH_LONG).show();
                                                    Intent intent1 = new Intent(signup.this, Launcher.class);
                                                    startActivity(intent1);
                                                }
                                            });
                                        }else {
                                            Toast.makeText(signup.this,task.getException().toString(), Toast.LENGTH_LONG).show();
                                        }

                                    }
                                });
                            }else {
                                Toast.makeText(signup.this,"You must be above 18 years of age", Toast.LENGTH_LONG).show();
                            }
                        }else {
                            Toast.makeText(signup.this, "All fields are compulsory", Toast.LENGTH_LONG).show();
                        }
                    }catch (Exception e){
                        Toast.makeText(signup.this, "Please Select Birth Date", Toast.LENGTH_LONG).show();
                    }

                }
            }
        });

    }



}
