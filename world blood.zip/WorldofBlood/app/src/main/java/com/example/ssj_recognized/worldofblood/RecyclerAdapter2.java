package com.example.ssj_recognized.worldofblood;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


public class RecyclerAdapter2 extends  RecyclerView.Adapter<RecyclerAdapter2.ViewHolder>{


    ArrayList<String> names, city1, uids, contact, bdate, blood;

    DatabaseReference mydatabase = FirebaseDatabase.getInstance().getReference();
    FirebaseAuth auth = FirebaseAuth.getInstance();







    private Context mContext;

    public RecyclerAdapter2(ArrayList<String> Names, ArrayList<String> City, ArrayList<String> Contact, ArrayList<String> Bdate, ArrayList<String> Blood, ArrayList<String> UIDS, Context context){
        names = Names;
        city1 = City;
        contact = Contact;
        bdate = Bdate;
        blood = Blood;
        uids = UIDS;

        mContext = context;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapterlayout2, parent, false);
        ViewHolder holder = new ViewHolder(view);


        return holder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        holder.name.setText(names.get(position));
       // holder.city.setText(city1.get(position));
        holder.bdatext.setText(bdate.get(position));
        holder.bloodtext.setText(blood.get(position));
        holder.accept.setText(contact.get(position));



        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+holder.accept.getText().toString()));
                mContext.startActivity(intent);





            }
        });

        holder.whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendIntent = new Intent("android.intent.action.MAIN");
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.setType("text/plain");
                sendIntent.putExtra(Intent.EXTRA_TEXT, "This is my text to send.");
                sendIntent.putExtra("jid", "91"+contact.get(position) + "@s.whatsapp.net");
                sendIntent.setPackage("com.whatsapp");
                mContext.startActivity(sendIntent);
            }
        });

    }




    @Override
    public int getItemCount() {
        return names.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        TextView name, city, bdatext, bloodtext;
        ImageView whatsapp;
        RelativeLayout parentLayout;
        Button accept;


        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            city = itemView.findViewById(R.id.city);
            bdatext = itemView.findViewById(R.id.bdate);
            bloodtext = itemView.findViewById(R.id.blood);
            whatsapp = itemView.findViewById(R.id.whatsapp);

            accept = itemView.findViewById(R.id.call);






        }
    }
}
