package com.example.ssj_recognized.worldofblood;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class fetchRequest extends AppCompatActivity {

    RecyclerView fetchRequest;

    ArrayList<String> names, uids, city;
    String city1;
    long size, count;

    DatabaseReference mydatabase = FirebaseDatabase.getInstance().getReference();
    FirebaseAuth auth = FirebaseAuth.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fetch_request);



        names = new ArrayList<>();
        uids = new ArrayList<>();
        city = new ArrayList<>();


        mydatabase.child(auth.getCurrentUser().getDisplayName()).child(auth.getCurrentUser().getUid())
                .child("requests").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                size = dataSnapshot.getChildrenCount();

                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                    uids.add(dataSnapshot1.getKey());
                    names.add(dataSnapshot1.child("name").getValue().toString());
                    city.add(dataSnapshot1.child("city").getValue().toString());
                    count++;
                }

                if (size == count){
                    Log.d("settttter", "SETTTTTERR CALLED");
                    RecyclerView recyclerView = (RecyclerView)findViewById(R.id.fetchRequest);

                    RecyclerAdapter1 adapter = new RecyclerAdapter1(names
                            , city, uids, fetchRequest.this);
                    recyclerView.setAdapter(adapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(fetchRequest.this));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



    }
}
